# CINEYA Delivery MVP starter

Ce dépôt est un **point de départ technique**, pas encore la plateforme complète de production.

## Inclus dans cette première base
- Interface responsive en français et arabe (RTL/LTR).
- Inscription et connexion avec mots de passe hachés.
- Fonction « Mot de passe oublié » et endpoint de réinitialisation par jeton.
- Base SQLite persistante.
- Création d'entreprise avec statut `ACTIVE_UNDER_REVIEW`.
- Annuaire d'entreprises.
- Soumission de demandes de livraison.
- Acceptation atomique d'une commande par un seul responsable propriétaire.
- Affectation de livreur (contrôle de base).
- Statuts de commande et journal d'événements.
- Manifeste PWA installable depuis un navigateur compatible.

## Important : limites actuelles
- Aucun APK Android natif n'est généré par ce dépôt.
- Le backend doit être hébergé sur un serveur accessible par tous les téléphones pour partager les données.
- Le canal de récupération du mot de passe (SMS/e-mail) n'est **pas connecté**. En développement, le jeton est écrit dans la console du serveur. Ne déployez pas ainsi en production.
- Pas encore de fournisseur SMS, e-mail, notifications push, cartes/GPS en temps réel, vérification téléphonique, gestion complète des permissions par entreprise, console Super Admin complète, sauvegardes automatisées ni tests de sécurité indépendants.
- La création d'entreprise dans ce MVP ne vérifie pas réellement le téléphone. Il faut intégrer un fournisseur de vérification avant d'autoriser la création en production.
- La PWA n'est pas équivalente à un APK natif et le mode d'installation dépend du navigateur et de l'hébergement HTTPS.

## Lancer localement (ordinateur)
1. Installer Node.js 20 ou version plus récente.
2. Décompresser le projet.
3. Dans le dossier du projet, exécuter `npm install`.
4. Copier `.env.example` vers `.env` et définir `JWT_SECRET` avec une longue valeur aléatoire.
5. Exécuter `npm start`.
6. Ouvrir `http://localhost:3000`.

Pour que tes amis utilisent le même système, déployer le backend et le dossier `public` sur un hébergement HTTPS avec stockage persistant. Ne pas utiliser le serveur local de ton téléphone comme serveur permanent.

## Avant une utilisation réelle
- Connecter un service réel de vérification téléphone.
- Connecter un service e-mail/SMS pour réinitialiser les mots de passe; ne jamais afficher les jetons aux utilisateurs ni les écrire dans les logs de production.
- Ajouter un vrai workflow d'adhésion et de recrutement, avec autorisations côté serveur.
- Mettre en place les rôles/permissions multi-entreprises complets et une procédure sécurisée d'initialisation du premier `SUPER_ADMIN`.
- Finaliser GPS, consentement, suivi en arrière-plan, rétention et permissions.
- Ajouter tests automatisés, tests concurrents d'acceptation, sauvegardes/restauration et audit de sécurité.
- Utiliser HTTPS, secrets d'environnement, sauvegardes et journalisation sans données sensibles.

## API initiale
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/forgot-password`
- `POST /api/auth/reset-password`
- `GET /api/me`
- `GET /api/companies`
- `POST /api/companies`
- `POST /api/orders`
- `GET /api/orders/mine`
- `POST /api/orders/:id/accept`
- `POST /api/orders/:id/assign-driver`
- `POST /api/orders/:id/status`
- `GET /api/orders/:id/events`

## Suite logique
1. Tester cette base localement.
2. Connecter un fournisseur réel d'authentification et de récupération.
3. Compléter les autorisations par entreprise.
4. Ajouter GPS et notifications.
5. Déployer le backend partagé.
6. Construire l'APK Android qui utilise la même API.
