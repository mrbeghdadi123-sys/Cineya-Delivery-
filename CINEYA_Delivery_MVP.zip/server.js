const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET === "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET") {
  if (process.env.NODE_ENV === "production") {
    throw new Error("Set a strong JWT_SECRET before production.");
  }
  console.warn("WARNING: Set JWT_SECRET in your environment before deployment.");
}
const secret = JWT_SECRET || "development-only-secret-change-me";
const db = new Database("cineya.sqlite");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT UNIQUE,
  email TEXT UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','COMPANY_OWNER','COMPANY_ADMIN','DRIVER','SUPER_ADMIN')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  city TEXT NOT NULL DEFAULT 'Saïda',
  phone TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'ACTIVE_UNDER_REVIEW',
  owner_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS memberships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  company_id INTEGER NOT NULL REFERENCES companies(id),
  role TEXT NOT NULL DEFAULT 'MEMBER',
  status TEXT NOT NULL DEFAULT 'PENDING',
  UNIQUE(user_id, company_id)
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  company_id INTEGER REFERENCES companies(id),
  pickup TEXT NOT NULL,
  dropoff TEXT NOT NULL,
  parcel_description TEXT DEFAULT '',
  customer_phone TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'SUBMITTED',
  accepted_by INTEGER REFERENCES users(id),
  driver_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS order_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  actor_id INTEGER REFERENCES users(id),
  old_status TEXT,
  new_status TEXT NOT NULL,
  note TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS password_resets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const safeUser = u => ({ id: u.id, name: u.name, phone: u.phone, email: u.email, role: u.role });
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try { req.user = jwt.verify(token, secret); next(); }
  catch { return res.status(401).json({ error: "Session invalide. Connectez-vous à nouveau." }); }
}
function ownsCompany(userId, companyId) {
  return !!db.prepare("SELECT 1 FROM companies WHERE id=? AND owner_id=?").get(companyId, userId);
}
function logEvent(orderId, actorId, oldStatus, newStatus, note = "") {
  db.prepare("INSERT INTO order_events(order_id,actor_id,old_status,new_status,note) VALUES(?,?,?,?,?)")
    .run(orderId, actorId || null, oldStatus || null, newStatus, note);
}

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "CINEYA Delivery", mode: "MVP starter" }));

app.post("/api/auth/register", async (req, res) => {
  const { name, phone, email, password } = req.body || {};
  if (!name?.trim() || (!phone?.trim() && !email?.trim()) || typeof password !== "string" || password.length < 10) {
    return res.status(400).json({ error: "Nom, téléphone ou e-mail, et mot de passe d'au moins 10 caractères requis." });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(name,phone,email,password_hash,role) VALUES(?,?,?,?, 'USER')")
      .run(name.trim(), phone?.trim() || null, email?.trim() || null, hash);
    const user = db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
    const token = jwt.sign({ id: user.id, role: user.role }, secret, { expiresIn: "12h" });
    res.status(201).json({ token, user: safeUser(user) });
  } catch (e) {
    if (String(e).includes("UNIQUE")) return res.status(409).json({ error: "Ce téléphone ou e-mail est déjà utilisé." });
    res.status(500).json({ error: "Création du compte impossible." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { identifier, password } = req.body || {};
  if (!identifier || !password) return res.status(400).json({ error: "Identifiant et mot de passe requis." });
  const user = db.prepare("SELECT * FROM users WHERE phone=? OR email=? COLLATE NOCASE").get(identifier.trim(), identifier.trim());
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Identifiant ou mot de passe incorrect." });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, secret, { expiresIn: "12h" });
  res.json({ token, user: safeUser(user) });
});

/* Password reset: always return the same public response to reduce account enumeration.
   In development only, the reset token is printed to the server console.
   Production MUST connect a real verified email/SMS delivery provider and remove token logging. */
app.post("/api/auth/forgot-password", (req, res) => {
  const { identifier } = req.body || {};
  const generic = { message: "Si ce compte existe, les instructions de réinitialisation seront envoyées par le canal configuré." };
  if (typeof identifier !== "string" || !identifier.trim()) return res.json(generic);
  const user = db.prepare("SELECT * FROM users WHERE phone=? OR email=? COLLATE NOCASE").get(identifier.trim(), identifier.trim());
  if (user) {
    const raw = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(raw).digest("hex");
    db.prepare("INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES(?,?,?)")
      .run(user.id, tokenHash, Date.now() + 30 * 60 * 1000);
    if (process.env.NODE_ENV !== "production") console.log(`[DEV ONLY] Password reset token for user ${user.id}: ${raw}`);
    // No email/SMS is sent by this starter until a real provider is configured.
  }
  res.json(generic);
});

app.post("/api/auth/reset-password", async (req, res) => {
  const { token, newPassword } = req.body || {};
  if (typeof token !== "string" || typeof newPassword !== "string" || newPassword.length < 10) {
    return res.status(400).json({ error: "Jeton invalide ou mot de passe trop court (10 caractères minimum)." });
  }
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  const reset = db.prepare("SELECT * FROM password_resets WHERE token_hash=? AND used=0 AND expires_at>?").get(tokenHash, Date.now());
  if (!reset) return res.status(400).json({ error: "Lien expiré ou invalide. Demandez une nouvelle réinitialisation." });
  const hash = await bcrypt.hash(newPassword, 12);
  const change = db.transaction(() => {
    db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hash, reset.user_id);
    db.prepare("UPDATE password_resets SET used=1 WHERE id=?").run(reset.id);
  });
  change();
  res.json({ message: "Mot de passe modifié. Vous pouvez vous reconnecter." });
});

app.get("/api/me", auth, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (!user) return res.status(401).json({ error: "Compte introuvable." });
  res.json({ user: safeUser(user) });
});

app.get("/api/companies", (_req, res) => {
  const rows = db.prepare("SELECT id,public_id,name,description,city,phone,status,created_at FROM companies WHERE status NOT IN ('SUSPENDED','CLOSED') ORDER BY name").all();
  res.json({ companies: rows });
});

app.post("/api/companies", auth, (req, res) => {
  const { name, description = "", city = "Saïda", phone = "" } = req.body || {};
  if (!name?.trim() || !city?.trim()) return res.status(400).json({ error: "Nom et ville requis." });
  const publicId = "CIN-" + crypto.randomBytes(4).toString("hex").toUpperCase();
  const create = db.transaction(() => {
    const result = db.prepare("INSERT INTO companies(public_id,name,description,city,phone,owner_id) VALUES(?,?,?,?,?,?)")
      .run(publicId, name.trim(), String(description).trim(), city.trim(), String(phone).trim(), req.user.id);
    db.prepare("UPDATE users SET role='COMPANY_OWNER' WHERE id=? AND role='USER'").run(req.user.id);
    return db.prepare("SELECT id,public_id,name,description,city,phone,status FROM companies WHERE id=?").get(result.lastInsertRowid);
  });
  try { res.status(201).json({ company: create() }); }
  catch { res.status(409).json({ error: "Impossible de créer cette entreprise." }); }
});

app.post("/api/orders", auth, (req, res) => {
  const { pickup, dropoff, parcelDescription = "", customerPhone = "", companyId = null } = req.body || {};
  if (!pickup?.trim() || !dropoff?.trim()) return res.status(400).json({ error: "Les adresses de collecte et de livraison sont obligatoires." });
  if (companyId && !db.prepare("SELECT 1 FROM companies WHERE id=? AND status NOT IN ('SUSPENDED','CLOSED')").get(companyId)) {
    return res.status(400).json({ error: "Entreprise indisponible." });
  }
  const publicId = "ORD-" + crypto.randomBytes(5).toString("hex").toUpperCase();
  const info = db.prepare("INSERT INTO orders(public_id,customer_id,company_id,pickup,dropoff,parcel_description,customer_phone,status) VALUES(?,?,?,?,?,?,?,'SUBMITTED')")
    .run(publicId, req.user.id, companyId, pickup.trim(), dropoff.trim(), String(parcelDescription).trim(), String(customerPhone).trim());
  logEvent(info.lastInsertRowid, req.user.id, null, "SUBMITTED", "Demande créée");
  res.status(201).json({ order: db.prepare("SELECT * FROM orders WHERE id=?").get(info.lastInsertRowid) });
});

app.get("/api/orders/mine", auth, (req, res) => {
  const rows = db.prepare(`
    SELECT o.* FROM orders o
    WHERE o.customer_id=? OR o.accepted_by=? OR o.driver_id=?
       OR (o.company_id IN (SELECT id FROM companies WHERE owner_id=?))
       OR (o.company_id IN (SELECT company_id FROM memberships WHERE user_id=? AND status='APPROVED'))
    ORDER BY o.id DESC LIMIT 200
  `).all(req.user.id, req.user.id, req.user.id, req.user.id, req.user.id);
  res.json({ orders: rows });
});

/* Atomic acceptance: only one concurrent manager can change SUBMITTED/PENDING_REVIEW to ACCEPTED. */
app.post("/api/orders/:id/accept", auth, (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(Number(req.params.id));
  if (!order) return res.status(404).json({ error: "Commande introuvable." });
  if (!order.company_id || !ownsCompany(req.user.id, order.company_id)) {
    const member = db.prepare("SELECT 1 FROM memberships WHERE user_id=? AND company_id=? AND status='APPROVED' AND role IN ('COMPANY_ADMIN','MANAGER')").get(req.user.id, order.company_id);
    if (!member) return res.status(403).json({ error: "Vous n'êtes pas autorisé à accepter cette commande." });
  }
  const tx = db.transaction(() => {
    const result = db.prepare("UPDATE orders SET status='ACCEPTED', accepted_by=?, updated_at=datetime('now') WHERE id=? AND status IN ('SUBMITTED','PENDING_REVIEW') AND accepted_by IS NULL")
      .run(req.user.id, order.id);
    if (result.changes !== 1) return false;
    logEvent(order.id, req.user.id, order.status, "ACCEPTED", "Acceptation atomique");
    return true;
  });
  if (!tx()) return res.status(409).json({ error: "Cette commande a déjà été acceptée ou son statut a changé." });
  res.json({ order: db.prepare("SELECT * FROM orders WHERE id=?").get(order.id) });
});

app.post("/api/orders/:id/assign-driver", auth, (req, res) => {
  const { driverId } = req.body || {};
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(Number(req.params.id));
  if (!order) return res.status(404).json({ error: "Commande introuvable." });
  if (!order.company_id || !ownsCompany(req.user.id, order.company_id)) return res.status(403).json({ error: "Seul le propriétaire de cette entreprise peut affecter un livreur dans ce MVP." });
  const driver = db.prepare("SELECT id,role FROM users WHERE id=?").get(Number(driverId));
  const member = db.prepare("SELECT 1 FROM memberships WHERE user_id=? AND company_id=? AND status='APPROVED'").get(Number(driverId), order.company_id);
  if (!driver || driver.role !== "DRIVER" || !member) return res.status(400).json({ error: "Le livreur doit être activé et associé à cette entreprise." });
  const result = db.prepare("UPDATE orders SET driver_id=?,status='ASSIGNED_TO_DRIVER',updated_at=datetime('now') WHERE id=? AND status='ACCEPTED' AND driver_id IS NULL").run(driver.id, order.id);
  if (result.changes !== 1) return res.status(409).json({ error: "La commande doit être acceptée et ne pas avoir de livreur." });
  logEvent(order.id, req.user.id, "ACCEPTED", "ASSIGNED_TO_DRIVER", "Livreur affecté");
  res.json({ order: db.prepare("SELECT * FROM orders WHERE id=?").get(order.id) });
});

app.post("/api/orders/:id/status", auth, (req, res) => {
  const allowed = new Set(["PICKED_UP","IN_TRANSIT","DELIVERED","DELIVERY_FAILED","RETURNED","CANCELLED"]);
  const { status, note = "" } = req.body || {};
  if (!allowed.has(status)) return res.status(400).json({ error: "Statut non autorisé." });
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(Number(req.params.id));
  if (!order) return res.status(404).json({ error: "Commande introuvable." });
  const allowedActor = order.driver_id === req.user.id || ownsCompany(req.user.id, order.company_id);
  if (!allowedActor) return res.status(403).json({ error: "Action non autorisée." });
  const result = db.prepare("UPDATE orders SET status=?,updated_at=datetime('now') WHERE id=? AND status NOT IN ('DELIVERED','CANCELLED','RETURNED')").run(status, order.id);
  if (!result.changes) return res.status(409).json({ error: "Commande terminée ou statut modifié." });
  logEvent(order.id, req.user.id, order.status, status, String(note).slice(0, 500));
  res.json({ order: db.prepare("SELECT * FROM orders WHERE id=?").get(order.id) });
});

app.get("/api/orders/:id/events", auth, (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(Number(req.params.id));
  if (!order) return res.status(404).json({ error: "Commande introuvable." });
  const permitted = order.customer_id === req.user.id || order.accepted_by === req.user.id || order.driver_id === req.user.id || ownsCompany(req.user.id, order.company_id);
  if (!permitted) return res.status(403).json({ error: "Accès refusé." });
  res.json({ events: db.prepare("SELECT old_status,new_status,note,created_at FROM order_events WHERE order_id=? ORDER BY id").all(order.id) });
});

app.listen(PORT, () => console.log(`CINEYA Delivery MVP listening on http://localhost:${PORT}`));
